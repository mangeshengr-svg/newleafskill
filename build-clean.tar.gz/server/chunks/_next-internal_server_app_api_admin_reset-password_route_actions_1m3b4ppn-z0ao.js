module.exports=[28068,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_reset-password_route_actions_1m3b4ppn-z0ao.js.map