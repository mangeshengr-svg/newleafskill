globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/oLDpZLhYQJOVUbWksZ-CX/_buildManifest.js",
    "static/oLDpZLhYQJOVUbWksZ-CX/_ssgManifest.js",
    "static/oLDpZLhYQJOVUbWksZ-CX/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1zgmbervt4bfj.js",
    "static/chunks/1xonfax3hcrx1.js",
    "static/chunks/0x3zgld0yn029.js",
    "static/chunks/41yg3r8a3egyx.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/craftsmanship/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/craftsmanship/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/craftsmanship/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/cta/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/global-presence/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/global-presence/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/global-presence/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/hero/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/machines/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/machines/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/machines/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/story/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/timeline/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/timeline/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/timeline/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/why-choose/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/why-choose/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/about/why-choose/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/blog/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/blog/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/blog/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/contact/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/contact/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/contact/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/faqs/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/faqs/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/faqs/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/home/embroidery/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/home/embroidery/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/home/embroidery/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/home/hero/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/home/slider/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/home/stitch-categories/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/home/stitch-categories/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/home/stitch-categories/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/login/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/our-work/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/our-work/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/our-work/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/register/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/reset-password/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/reviews/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/services/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/services/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/services/categories/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/services/categories/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/services/categories/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/services/categories/subcategories/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/services/categories/subcategories/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/services/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/settings/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/users/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/why-choose-us/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/why-choose-us/add/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(admin)/admin/why-choose-us/edit/[id]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/about/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/blog/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/blog/[slug]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/contact/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/our-work/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/ourwork/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/services/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/services/[slug]/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/work/page": {
      "otherChunks": [
        "static/chunks/1zgmbervt4bfj.js",
        "static/chunks/1xonfax3hcrx1.js",
        "static/chunks/0x3zgld0yn029.js",
        "static/chunks/41yg3r8a3egyx.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
