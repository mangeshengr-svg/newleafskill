module.exports=[29904,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_admin_users_page_actions_18-8fijqhg3-u.js.map