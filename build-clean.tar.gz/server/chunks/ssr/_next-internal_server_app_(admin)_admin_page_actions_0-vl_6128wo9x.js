module.exports=[64597,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28admin%29_admin_page_actions_0-vl_6128wo9x.js.map